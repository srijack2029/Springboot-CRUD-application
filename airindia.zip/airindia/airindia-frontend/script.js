const form = document.getElementById('registerForm');
const table = document.getElementById('resultTable');

const baseUrl = "http://localhost:8080/api/flightModel";

// Load data initially
showFlights();

form.addEventListener('submit', e => {
    e.preventDefault();

    const data = {
        id: document.getElementById('id').value,
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value,
        departure: document.getElementById('from').value,
        destination: document.getElementById('to').value,
        date: document.getElementById('date').value
    };

    const method = data.id ? "PUT" : "POST";
    const url = data.id ? `${baseUrl}/${data.id}` : baseUrl;

    console.log("Sending data:", data);

    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })


        .then(() => {
            form.reset();
            showFlights();
        })
        .catch(err => alert(err.message));
});

function showFlights() {
    fetch(baseUrl)
        .then(res => res.json())
        .then(data => {
            table.innerHTML = "";

            data.forEach(flightModel => {
                const row = `
                <tr>
                    <td>${flightModel.id}</td>
                    <td>${flightModel.name}</td>
                    <td>${flightModel.email}</td>
                    <td>${flightModel.address}</td>
                    <td>${flightModel.phone}</td>
                    <td>${flightModel.departure}</td>
                    <td>${flightModel.destination}</td>
                    <td>${flightModel.date}</td>

                  <td class="action-cell">
    <button class="update-btn" onclick='update(${JSON.stringify(flightModel)})'>
        Update
    </button>
    <button class="delete-btn" onclick='del(${flightModel.id})'>
        Delete
    </button>
</td>

                </tr>
                `;
                table.innerHTML += row;
            });
        })
        .catch(err => alert(err.message));
}

function update(flightModel) {
    document.getElementById('id').value = flightModel.id;
    document.getElementById('name').value = flightModel.name;
    document.getElementById('email').value = flightModel.email;
    document.getElementById('address').value = flightModel.address;
    document.getElementById('phone').value = flightModel.phone;
    document.getElementById('from').value = flightModel.departure;
    document.getElementById('to').value = flightModel.destination;
    document.getElementById('date').value = flightModel.date;
}

function del(id) {
    fetch(`${baseUrl}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) throw new Error("Delete failed");
            showFlights();
        })
        .catch(err => alert(err.message));
}
