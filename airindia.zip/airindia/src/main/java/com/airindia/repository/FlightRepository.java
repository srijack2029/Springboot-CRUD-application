package com.airindia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airindia.model.FlightModel;

	

	public interface FlightRepository extends JpaRepository<FlightModel, Long> {
	}

