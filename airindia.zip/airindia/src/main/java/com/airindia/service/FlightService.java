package com.airindia.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airindia.model.FlightModel;
import com.airindia.repository.FlightRepository;

@Service
public class FlightService {
	
@Autowired
FlightRepository flightRepository;

   public void addFlight(FlightModel flightModel) {
	   flightRepository.save(flightModel);
   }
   
   public List<FlightModel> getAllflightModel(){
	   return flightRepository.findAll();
	   
   }
   
   public FlightModel updateflightModel(FlightModel flightModel) {
	   return flightRepository.save(flightModel);
   }
   
   public void deleteflightModel(long id) {
	   flightRepository.deleteById(id);
   }
}
