package com.airindia.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airindia.model.FlightModel;
import com.airindia.service.FlightService;

@RestController
 @RequestMapping("/api/flightModel")
 @CrossOrigin("*")
 
 public class FlightController{
	
	@Autowired
	FlightService flightService;
	
	@PostMapping
	public void add (@RequestBody FlightModel flightModel) {
		flightService.addFlight(flightModel);
	}
	@GetMapping
	public List <FlightModel> get(){
		return flightService.getAllflightModel();
	}
	
	@PutMapping("/{id}")
	public FlightModel update (@PathVariable Long id, @RequestBody FlightModel flightModel) {
		return flightService.updateflightModel(flightModel);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> delete (@PathVariable long id) {
	    flightService.deleteflightModel(id);
	    return ResponseEntity.ok("Deleted successfully");
	}

}

 
 